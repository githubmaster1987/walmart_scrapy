<?php


/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('WP_CACHE', true); //Added by WP-Cache Manager
define( 'WPCACHEHOME', '/var/sites/g/guidetomatchedbetting.co.uk/public_html/wp-content/plugins/wp-super-cache/' ); //Added by WP-Cache Manager
define('DB_NAME', 'guidetom3_db');

/** MySQL database username */
define('DB_USER', 'guidetom3_db');

/** MySQL database password */
define('DB_PASSWORD', '4gp1w8vh14p5zf4m');

/** MySQL hostname */
define('DB_HOST', '10.169.0.101');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'QD8Atza3H4ajzXI2IrfNFia59vUsxOahKCqm97iRrz41IIg9UOmpSfViSTpJfXDy');
define('SECURE_AUTH_KEY',  '6XYmuO0iud9myxhTFAxy4yquDL4gcY3LwMXWuYSLNLCbCkfxDRb2aLld9noBOFmf');
define('LOGGED_IN_KEY',    'GxPvYVWGNwIJl3Sjio8MIllDA6aOiVexJqMcaAtFmFYeLOZwcmDm96YiqJ4yn2gC');
define('NONCE_KEY',        'xSyX6c1ItLxW86monVRd1fE9q81XHimGV2TKY4PLRdeS5t6KmnG7npnS2Mu3oZtq');
define('AUTH_SALT',        'Vom051E3OKihVcVXj2ufuFUHnBdcAK0UL371ywR8h73fCbrTML1OYZHXiIvSkP4z');
define('SECURE_AUTH_SALT', 'TKm6gv6fh4z41rVspLrfUlqY4gfLaHV01f6Qm8HzHjrVZNGoWA2tQJGtdZih71oN');
define('LOGGED_IN_SALT',   'Q3AqpFwZp8tSaFBeYMelpKqP36vfxR6OhKwMMCaxcK7t8foqwnzoHsSRwSRwDWVA');
define('NONCE_SALT',       'BlU9ikmwzLAT911GAtTSMwUr2cF8Bg3yEjdWl5skH2fmr6JzyhmnIYGi70qYMSf9');

/**
 * Other customizations.
 */
define('FS_METHOD','direct');define('FS_CHMOD_DIR',0755);define('FS_CHMOD_FILE',0644);
define('WP_TEMP_DIR',dirname(__FILE__).'/wp-content/uploads');

/**
 * Turn off automatic updates since these are managed upstream.
 */
define('AUTOMATIC_UPDATER_DISABLED', true);


/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'vxse_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

define("COOKIE_DOMAIN", "www.guidetomatchedbetting.co.uk");
/*define("WP_CONTENT_URL", "http://cdn.guidetomatchedbetting.co.uk");*/

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');