<?php header("HTTP/1.0 404 Not Found");exit;?>
db-pass=4gp1w8vh14p5zf4m