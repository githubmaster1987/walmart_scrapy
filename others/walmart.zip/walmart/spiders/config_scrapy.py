output_category_csv_name = "category.csv"

db_host = 'localhost'
db_user = 'root'
db_pwd = 'root'
db_database = 'walmart_db'
