# -*- coding: utf-8 -*-

# Define your item pipelines here
#
# Don't forget to add your pipeline to the ITEM_PIPELINES setting
# See: http://doc.scrapy.org/en/latest/topics/item-pipeline.html

import spiders.config_scrapy as config
import MySQLdb as mdb
import numbers
import json
import googlemaps
from datetime import datetime
from items import WalmartItem
import logging

con = mdb.connect(config.db_host, config.db_user, config.db_pwd, config.db_database)

class WalmartPipeline(object):
    def insert_many(self,sql, sqldata):
        with con:
            cur = con.cursor()
            cur.executemany(sql, sqldata)
            con.commit()

    def update_sql(self,sql, sqldata):
        with con:
            cur = con.cursor()
            cur.execute(sql, sqldata)
            con.commit()

    def process_item(self, item, spider):
        if isinstance(item, WalmartItem):
            self.insert_products(item)
        return item

    def retrieve_data(self,sql):
        with con:
            cur = con.cursor()
            cur.execute(sql)
            rows = cur.fetchall()
            return rows

    def delete_product():
        sql  = "DELETE FROM product"
        execute_sql(sql)

        sql  = "DELETE FROM product_picture"
        execute_sql(sql)

        sql  = "DELETE FROM product_options"
        execute_sql(sql)

        sql  = "DELETE FROM product_detail"
        execute_sql(sql)


    def insert_products(self, item):
        products = self.retrieve_data("select * from product where product_id=" + item["unique_id"])

        # product_url = scrapy.Field()
        # product_name = scrapy.Field()
        # unique_id = scrapy.Field()
        # cost = scrapy.Field()
        # delivery_time = scrapy.Field()
        # pictures_url = scrapy.Field()
        # bullet_points = scrapy.Field()
        # details = scrapy.Field()
        # review_numbers = scrapy.Field()
        # category = scrapy.Field()
        # inventory = scrapy.Field()
        # options = scrapy.Field()
        # seller = scrapy.Field()
        # product_type = scrapy.Field()
        
        if len(products) >0:
            return
        
        picture_data_list = []
        
        picture_sql = "INSERT INTO product_picture (product_id, picture_url, create_date) VALUES (%s, %s, Now())"
        for picture in item["pictures_url"]:
            picture_data = (int(item["unique_id"]), picture)
            picture_data_list.append(picture_data)

        option_data_list = []
        option_sql = "INSERT INTO product_options (product_id, option_size, option_color, value, create_date) VALUES (%s, %s, %s, %s, Now())"
        for option in item["cost_option"]:
            option_data = (int(item["unique_id"]), option["size"], option["color"], option["price"])
            option_data_list.append(option_data)

        detail_data_list = []
        detail_sql = "INSERT INTO product_detail (product_id, detail_name, detail_value, create_date) VALUES (%s, %s, %s, Now())"
        for detail in item["details"]:
            detail_data = (int(item["unique_id"]), detail["name"], detail["value"])
            detail_data_list.append(detail_data)

        product_sql = """INSERT INTO product(product_id, product_type, delivery_time, product_name, product_url, \
            review_numbers, cost, bullet_points, seller, option_size, option_color, category, inventory, create_date, special_offer, fulfillment) VALUES (\
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                %s,
                Now(),
                %s,
                %s)"""

        product_data_list = []
        
        #Product product Part
        product_data = (
            int(item["unique_id"]),        #product_id
            item["product_type"],                             #product_type
            item["delivery_time"],                       #delivery_time
            item["product_name"],              #product_name
            item["product_url"],                            #product_url
            item["review_numbers"],                            #review_numbers
            item["cost"],                            #cost
            item["bullet_points"],                            #bullet_points
            item["seller"],                            #seller
            ",".join(item["option_size"]),                  #option_size
            ",".join(item["option_color"]),                 #option_color
            item["category"],                            #category
            item["inventory"],                          #inventory
            item["special_offer"],                      # speciall offer
            json.dumps(item["fulfillment"]))                            #shipping info

        product_data_list.append(product_data)

        self.insert_many(product_sql, product_data_list)
        self.insert_many(picture_sql, picture_data_list)
        self.insert_many(option_sql, option_data_list)
        self.insert_many(detail_sql, detail_data_list)