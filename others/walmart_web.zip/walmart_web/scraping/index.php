<style>
.jtable-column-header
{
  height:70px;
}
</style>
 
<div class="container-fluid">
  <form class="form-horizontal" id="scrapingForm" enctype="multipart/form-data" method="post" name="scrapingForm">
    <input type="hidden" name="running" value="0"/>
    <div class="form-group">
      <div class="col-sm-12 text-center">
        <h1>Quick Scraping</h1>
      </div>
    </div>
    <div class="form-group">
      <label for="unique_ids" class="col-sm-2 control-label">Unique IDs</label>
      <div class="col-sm-3">
        <input type="file" class="form-control" id="unique_ids" name="unique_ids">
      </div>
    </div>
    <div class="form-group">
      <label for="mode" class="col-sm-2 control-label">Mode</label>
      <div class="col-sm-2">
        <select name="mode" id="mode" class="form-control">
          <option value="Compatible">Compatible</option>
          <option value="Standard">Standard</option>
        </select>
      </div>
      <label for="duration" class="col-sm-2 control-label">Duration</label>
      <div class="col-sm-1">
        <input type="text" class="form-control" id="duration" name="duration" value="15">
      </div>
      <div class="col-sm-2 text-left">
        <button type="button" class="btn btn-primary" id="start_btn">Start</button>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-12">
        <div id="ScrapingDataTableContainer" class="centered"></div>
        <div id="ScrapingDetailDataTableContainer" class="centered"></div>
      </div>
    </div>
  </form>
</div>
<script type="text/javascript">
  var fields;
  $(document).ready(function () {
      url = '<?php echo $server_addr; ?>data/product.php?category=product_health&title=Health';

      $('#ScrapingDataTableContainer').jtable({
          title: 'The Product List',
            paging: true, //Enable paging
            pageSize: 10, //Set page size (default: 10)
            sorting: true, //Enable sorting
            defaultSorting: 'Name ASC', //Set default sorting
            actions: {
                listAction: url,
                // deleteAction: '/Demo/DeleteStudent',
                // updateAction: '/Demo/UpdateStudent',
                // createAction: '/Demo/CreateStudent'
            },
            fields: {
              product_id: {
                  key: true,
                  create: false,
                  edit: false,
                  list: true,
                  title : "Unique<br/>Identifier",
              },
              product_name: {
                  title: 'Title',
              },
              product_type: {
                  title: 'Product Type',
                  
              },
              cost: {
                  title: 'Cost',
              },
              inventory: {
                  title: 'Inventory',
              },
            }
        });

        $('#ScrapingDetailDataTableContainer').jtable({
            title: 'The Product List',
            paging: true, //Enable paging
            pageSize: 10, //Set page size (default: 10)
            sorting: true, //Enable sorting
            defaultSorting: 'Name ASC', //Set default sorting
            actions: {
                listAction: url,
                // deleteAction: '/Demo/DeleteStudent',
                // updateAction: '/Demo/UpdateStudent',
                // createAction: '/Demo/CreateStudent'
            },
            fields: {
                product_id: {
                    key: true,
                    create: false,
                    edit: false,
                    list: true,
                    title : "Unique Identifier",
                },
                product_name: {
                    title: 'Title',
                },
                cost: {
                    title: 'Cost',
                },
                product_type: {
                    title: 'Product Type',
                    
                },
                delivery_time: {
                    title: 'Delivery Time',
                },
                picture_url: {
                    title: 'Pictures',
                },
                bullet_points: {
                    title: 'Bullet Points',
                },
                details: {
                    title: 'Details',
                },
                options: {
                    title: 'Options',
                },
                product_url: {
                    title: 'Url',
                },
                review_numbers: {
                    title: 'Reviews',
                },
                seller: {
                    title: 'Seller',
                },
                category: {
                    title: 'Category',
                },
                inventory: {
                    title: 'Inventory',
                },
                special_offer: {
                    title: 'Special Offer',
                },
                scraping_date: {
                    title: 'Date Time',
                }
            }
        });
      

      var load_jtable = function()
      {
        //Load student list from server
        $('#ScrapingDataTableContainer').jtable('load');
        $('#ScrapingDetailDataTableContainer').jtable('load');

        if($("#mode").val() == "Standard")
          {
            $('#ScrapingDataTableContainer').hide();
            $('#ScrapingDetailDataTableContainer').show();
            $.each( $(".jtable thead tr th"), function(index) {
                  if (index == 0) {
                    console.log(index);
                    $(this).width("30%");
                  }                                                                                                               
              });
          }
          else
          {
            $('#ScrapingDetailDataTableContainer').hide();
            $('#ScrapingDataTableContainer').show();
            $.each( $(".jtable thead tr th"), function(index) {
                if (index == 0)
                  $(this).width("10%");
                else if (index == 1)
                  $(this).width("60%");
                else if(index == 2)
                  $(this).width("10%");
                else if(index == 3)
                  $(this).width("10%");
                else if(index == 4)
                  $(this).width("10%");
            });
          }

      }
      $("#mode").change(function(){
          load_jtable();
      });

      load_jtable();
      // setInterval(function(){
      //     var currentLocation = window.location; 
      //     window.location.href = currentLocation;         
      // }, 5 * 60 * 1000);
  });

  var run_process = function()
      {
        jQuery.ajax({
          type: "POST",
          url: '<?=$server_addr?>data/process.php',
          dataType: 'json',
          data: {
            type: "run",
          },
          success: function (obj) {
              console.log(obj);
              if (obj.Run_Result == 1)
              {
              }
          }
        });
      }
      $("#start_btn").click(function() {
        upload_csv();
        return;
        
        jQuery.ajax({
          type: "POST",
          url: '<?=$server_addr?>data/process.php',
          dataType: 'json',
          data: {
            type: "check",
          },
          success: function (obj) {
            console.log(obj);
              if (obj.Check_Result == 0)
              {
                upload_csv();
              }
              else
              {
                //alert('Process is running now');
                return;
              }
          }
        });
      });

      var upload_csv = function() {
          // if ($("#unique_ids").val() == "") {
          //     alert("Please select file.");
          //     return;
          // }
          var formData = new FormData($("#scrapingForm")[0]);
          formData.append("type", "upload");
          
          jQuery.ajax({
              type: "POST",
              url: '<?=$server_addr?>data/process.php',
              cache: false,
              contentType: false,
              processData: false,
              data: formData,
              success: function (obj) {
                  console.log(obj);
                  //run_process();
              }
          });
      }

</script>
