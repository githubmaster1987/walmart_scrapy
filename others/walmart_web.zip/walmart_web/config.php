<?php
$server_addr = "http://".$_SERVER["HTTP_HOST"]."/walmart_web/";
$upload_path = "/home/kevinying/Downloads/";
?>