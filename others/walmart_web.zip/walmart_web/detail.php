<style>
.jtable-column-header
{
  height:70px;
}
 .jtable>thead>tr>th:nth-child(2)>div{
    width:200px;
 }
 .jtable>thead>tr>th:nth-child(4)>div{
    width:100px;
 }
.jtable>thead>tr>th:nth-child(6)>div{
    width:500px;
 }

.jtable>thead>tr>th:nth-child(7)>div{
    width:300px;
 }

.jtable>thead>tr>th:nth-child(8)>div{
    width:600px;
 }

.jtable>thead>tr>th:nth-child(9)>div{
    width:300px;
 }
.jtable>thead>tr>th:nth-child(15)>div{
    width:100px;
 }
 
 </style>
  <script type="text/javascript">
     $(document).ready(function () {
        url = 'data/product.php?category=' + $('#category').val() + "&unique_id=" + $("#unique_id").val() + "&product_title=" + $("#product_title").val();
        $('#ProductTableContainer').jtable({
            title: 'The Product List',
            paging: true, //Enable paging
            pageSize: 10, //Set page size (default: 10)
            sorting: true, //Enable sorting
            defaultSorting: 'Name ASC', //Set default sorting
            actions: {
                listAction: url,
                // deleteAction: '/Demo/DeleteStudent',
                // updateAction: '/Demo/UpdateStudent',
                // createAction: '/Demo/CreateStudent'
            },
            fields: {
                product_id: {
                    key: true,
                    create: false,
                    edit: false,
                    list: true,
                    title : "Unique Identifier",
                },
                product_name: {
                    title: 'Title',
                },
                cost: {
                    title: 'Cost',
                },
                product_type: {
                    title: 'Product Type',
                    
                },
                delivery_time: {
                    title: 'Delivery Time',
                },
                picture_url: {
                    title: 'Pictures',
                },
                bullet_points: {
                    title: 'Bullet Points',
                },
                details: {
                    title: 'Details',
                },
                options: {
                    title: 'Options',
                },
                product_url: {
                    title: 'Url',
                },
                review_numbers: {
                    title: 'Reviews',
                },
                seller: {
                    title: 'Seller',
                },
                category: {
                    title: 'Category',
                },
                inventory: {
                    title: 'Inventory',
                },
                special_offer: {
                    title: 'Special Offer',
                },
                scraping_date: {
                    title: 'Date Time',
                }
            }
        });
 
        //Load student list from server
        $('#ProductTableContainer').jtable('load');
    });

  </script>
<form class="form-horizontal" method="post">
<div class="row">
    <div class="form-group">
      <div class="col-sm-12 text-center">
        <h1>Product Lists for <?=$_REQUEST['title']?></h1>
      </div>
    </div>
    <div class="form-group">
      <label for="unique_id" class="col-sm-1 control-label text-right">Unique ID</label>
      <div class="col-sm-2">
        <input type="text" class="form-control" id="unique_id" name="unique_id" value="<?php echo $_REQUEST["unique_id"];?>">
      </div>
      <label for="title" class="col-sm-1 control-label text-right">Title</label>
      <div class="col-sm-4">
        <input type="text" class="form-control" id="product_title" name="product_title" value="<?php echo $_REQUEST["product_title"];?>">
      </div>
      <button type="submit" class="btn btn-primary">Search</button>
      
    </div>
    <div class="form-group">
        <div id="ProductTableContainer" class="col-sm-12" style="margin:10px;"></div>
    </div>
</div>
<input type="hidden" id="category" name="category" value="<?=$_REQUEST['category']?>"/>
<input type="hidden" id="title" name="title" value="<?=$_REQUEST['title']?>"/>
<input type="hidden" id="type" name="type" value="detail"/>
</form>
