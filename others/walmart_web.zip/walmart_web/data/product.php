<?php
require_once "config_db.php";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 

$table = $_REQUEST["category"];

$sql = "SELECT * FROM ".$table." WHERE 1=1";

if (isset($_REQUEST["unique_id"]))
{
	$sql = $sql." and product_id Like '%".$_REQUEST["unique_id"]."%' ";
}

if (isset($_REQUEST["unique_id"]))
{
	$sql = $sql." and product_name Like '%".$_REQUEST["product_title"]."%' ";
}

if (isset($_REQUEST["jtSorting"]))
{
    $sql = $sql." ORDER BY ".$_REQUEST['jtSorting'];
}

$sql = $sql." LIMIT ".$_REQUEST['jtStartIndex'].", ".$_REQUEST['jtPageSize'];


$result = $conn->query($sql);
$rows = [];

if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
        $rows[] = $row;
    }
} else {
    echo "0 results";
}

$total = $conn->query("Select * FROM ".$table)->num_rows;
 
//Return result to jTable
$jTableResult = array();
$jTableResult['Result'] = "OK";
$jTableResult['Records'] = $rows;
$jTableResult['TotalRecordCount'] = $total;

print json_encode($jTableResult);
$conn->close();
?>