<?php
$servername = "localhost";
$username = "root";
$password = "root";
$dbname = "walmart_db";

$db_tables = '{
		"Toys" : "product_toys",
	    "Photo Center" : "product_photo_center",
	    "Pets" : "product_pets",
	    "Video Games" : "product_video_games",
	    "Pharmacy" : "product_pharmacy",
	    "Home" : "product_home",
	    "Sports & Outdoors" : "product_sports_outdoors",
	    "Seasonal" : "product_seasonal",
	    "Health" : "product_health",
	    "Musical Instruments" : "product_musical_instruments",
	    "Movies & TV" : "product_movies_tv",
	    "Music" : "product_music",
	    "Patio & Garden" : "product_patio_garden",
	    "Party & Occasions" : "product_party_occasions",
	    "Household Essentials" : "product_household_essentials",
	    "Baby" : "product_baby",
	    "Office" : "product_office",
	    "Books" : "product_books",
	    "Gifts & Registry" : "product_gifts_registry",
	    "Cell Phones" : "product_cell_phones",
	    "Food" : "product_food",
	    "Beauty" : "product_beauty",
	    "Home Improvement" : "product_home_improvement",
	    "Clothing" : "product_clothing",
	    "Electronics": "product_electronics",
	    "Auto & Tires": "product_auto_tires",
	    "Jewelry" : "product_jewelry"
	}';
?>