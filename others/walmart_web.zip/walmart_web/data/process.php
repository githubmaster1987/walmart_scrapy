<?php
require_once "../config.php";
function processExists($processName) {
    $exists= 0;
    $proc = exec("ps -ax | grep -i $processName | grep -v grep", $pids);
    
    if (count($pids) > 0) {
        for($i = 0; $i < count($pids); $i++)
        {
            $str = $pids[$i];
            #if(strpos($str, "scrapy crawl walmartspider -a method=upload") == TRUE)
            if(strpos($str, "scrapy crawl walmartspider") == True)
                $exists = 1;
        }
    }
    return $exists;
}

function runProcess($dir, $command) {
	chdir($dir);
	echo shell_exec($command);
	echo getcwd() . "<br>";
	return true;
}

function uploadFile()
{
    global $upload_path;
    $_FILES_name = "";
    $file = $_FILES["unique_ids"];
    $file_name = basename($file["name"]);
    $target_dir = $upload_path;
    $file_name = "ids.csv";
    $target_file = $target_dir .$file_name;
    
    if (move_uploaded_file($file["tmp_name"], $target_file)) {
        return 1;
    } 
    return 0;
}

$cmd = 'scrapy crawl walmartspider -a category="Video Games"';
$dir = '/home/kevinying/walmart';

if(isset($_REQUEST["type"]))
{
    $type = $_REQUEST["type"];
    switch($type)
    {
        case 'check':
            $status = processExists("scrapy");
            $ret["Check_Result"] = $status;
            echo json_encode($ret);    
            break;
        case 'run':
            $status = processExists("scrapy");
            if ($status == 0) {
                #runProcess($dir, $cmd);
                $status = 1;
            }

            $ret["Run_Result"] = $status;
            echo json_encode($ret);    
            break;
        case 'upload':
            $status = uploadFile();
            $ret["Upload_Result"] = $status;
            echo json_encode($ret);    
            break;
    }
}
?>