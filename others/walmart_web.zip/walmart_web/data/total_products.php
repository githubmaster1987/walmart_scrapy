<?php

require_once "config_db.php";
// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 
$tables = json_decode($db_tables);
$rows = [];

foreach($tables as $key=>$value)
{	
	$sql = "Select count(product_id) as cnt FROM ".$value;

	$result = $conn->query($sql);
	$total = 0;
	while ($row = $result->fetch_object()){
		$total = $row->cnt; 
    }
	
	$row["name"] = $key;
		
	switch($key)
	{
		case 'Sports & Outdoors':
			$total = 0;
			break;
		case 'Seasonal':
			$total = 0;
			break;
		case 'Musical Instruments':
			$total = 0;
			break;
		case 'Movies & TV':
			$total = 0;
			break;
		case 'Music':
			$total = 0;
			break;
		case 'Patio & Garden':
			$total = 0;
			break;
		case 'Party & Occasions':
			$total = 0;
			break;
		case 'Household Essentials':
			$total = 0;
			break;
		case 'Baby':
			$total = 0;
			break;
		case 'Office':
			$total = 0;
			break;
		case 'Books':
			$total = 0;
			break;
		case 'Gifts & Registry':
			$total = 0;
			break;
		case 'Cell Phones':
			$total = 0;
			break;
		case 'Food':
			$total = 0;
			break;
		case 'Beauty':
			$total = 0;
			break;
		case 'Home Improvement':
			$total = 0;
			break;
		case 'Clothing':
			$total = 0;
			break;
		case 'Electronics':
			$total = 0;
			break;
		// case 'Auto & Tires':
		// 	$total = 0;
		// 	break;
		case 'Jewelry':
			$total = 0;
			break;
	}

	$row["count"] = $total;
	$link_str = "";
	if ($total > 0)
		$link_str = "<a href='index.php?type=detail&category=$value&title=$key'> Show Items</a>"; 
	$row["link"] = $link_str;
	array_push($rows, $row);
}

//Return result to jTable
$jTableResult = array();
$jTableResult['Result'] = "OK";
$jTableResult['Records'] = $rows;
$jTableResult['TotalRecordCount'] = $total;

print json_encode($jTableResult);
$conn->close();
?>