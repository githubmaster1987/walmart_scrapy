<div class="row">
    <div class="form-group">
      <div class="col-sm-10 text-center">
        <h1>Product Lists by Category</h1>
      </div>
    </div>
    <div class="form-group">
      <div class="col-sm-11 text-right">
        <a href="?type=scraping">Quick Scraping</a>
      </div>
    </div>
    <div id="ProductTableContainer" class="col-sm-10 col-sm-offset-1"></div>
</div>

<script type="text/javascript">
     $(document).ready(function () {
         $('#ProductTableContainer').jtable({
            title: 'The Product List',
            paging: false, //Enable paging
            pageSize: 30, //Set page size (default: 10)
            sorting: true, //Enable sorting
            defaultSorting: 'Name ASC', //Set default sorting
            actions: {
                listAction: 'data/total_products.php',
            },
            fields: {
                name: {
                    title: 'Category Name',
                },
                count: {
                    title: 'Row Counts',
                },
                link: {
                    title: 'Link',
                },
            }
        });
 
        //Load student list from server
        $('#ProductTableContainer').jtable('load');

        setInterval(function()
        {
            var currentLocation = window.location; 
            window.location.href = currentLocation;         
        }, 5 * 60 * 1000);
    });
</script>