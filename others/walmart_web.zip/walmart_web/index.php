<?php
  require_once("config.php");
?>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Walmart Products Information</title>
  <script src="<?=$server_addr?>asset/jquery/jquery.min.js"></script>
  <script src="<?=$server_addr?>asset/jquery-ui.js"></script>
  <link rel="stylesheet" href="<?=$server_addr?>asset/jquery-ui.css">

<!-- Bootstrap Date-Picker Plugin -->
 <link rel="stylesheet" href="<?=$server_addr?>asset/bootstrap/css/bootstrap.min.css">
<!-- Latest compiled and minified JavaScript -->
<script src="<?=$server_addr?>asset/bootstrap/js/bootstrap.min.js"></script>


<!-- Include one of jTable styles. -->
<link href="<?=$server_addr?>asset/jtable/themes/metro/blue/jtable.min.css" rel="stylesheet" type="text/css" />
 <!-- Include jTable script file. -->
<script src="<?=$server_addr?>asset/jtable/jquery.jtable.min.js" type="text/javascript"></script>
</head>
<body>

<?php
  $type = "";
  if(isset($_REQUEST['type']))
    $type =  $_REQUEST['type'];

  switch($type)
  {
    case '':
      require("main_content.php");
      break;
    case 'scraping':
      require("scraping/index.php");
      break;
    case 'detail':
      require("detail.php");
      break;
  }
?>
</body>
</html>